1.Choose Tools > Extensions.

2.If Developer mode has a + by it, click the +. 
The + changes to a -, and more buttons and information appear.

3.Click the Load unpacked extension button. A file dialog appears.

4.In the file dialog, choose the sample_extension directory. Unless you get an error dialog, you've now installed the sample_extension.

5.Troubleshooting: 
	If you get an error dialog saying you could not load the extension, make sure your manifest file has valid JSON formatting and is called manifest.json (not manifest.json.txt or manifest.json.rtf, for example). You can use a JSON validator to make sure your manifest's format is valid. Often, formatting issues are related to commas (,) and quotation marks (")—either too many or not enough. For example, the last entry in the manifest should not have a comma after it.

6.Create a new tab.
 
	The icon for the newly installed sample extension appears in Google Chrome's launcher on the New Tab page. If the Apps area is minimized, then instead of the icon you specified, you should see the website favicon.

7.Click the icon for the sample extension. 
	You've now launched the sample extension. You should see its website in your browser window. If you don't, try changing the value of "web_url" in the manifest, reload the sample extension, and click its icon again
